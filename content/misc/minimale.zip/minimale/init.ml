(* init.ml *)

(* Les types de données *)
(* Un point appartient soit à un des bords (chacun a un numéro, on
   garde aussi le paramètre), soit à rien (None) *)
type vec = { x : float; y : float; z : float }
type point = { p : vec; crb : int option; t : float }
let orig = {x = 0.; y = 0.; z = 0.}
let pt p = { p = p; t = 0.; crb = None }

let pi = acos (-1.)

(* Affiche les types *)
let aff_pt p = Printf.sprintf "(%.3f,%.3f,%.3f)" p.x p.y p.z
let aff_pt_crb p = aff_pt p.p

(* Programmation fonctionnelle *)
let ( @@ ) f g x = f (g x)
let ( @$ ) f x = f x
let foi = float_of_int
let iof = int_of_float

(* Opérations sur les points : espace vectoriel, euclidien, produit
   vectoriel *)
let ( +! ) m n = { x = m.x +. n.x; y = m.y +. n.y; z = m.z +. n.z }
let ( *! ) l m = { x = l *. m.x; y = l *. m.y; z = l *. m.z }
let ( -! ) m n = m +! (-1. *! n)
let ( !- ) m = orig -! m
let ( *^ ) m n = { x = m.y *. n.z -. m.z *. n.y;
                   y = m.z *. n.x -. m.x *. n.z;
                   z = m.x *. n.y -. m.y *. n.x }
let pdt_scal m n = m.x *. n.x +. m.y *. n.y +. m.z *. n.z
let distance m n = sqrt (pdt_scal (m -! n) (m -! n))
let norme m = distance m orig

(* Convertit coordonées sphériques => cartésiennes *)
let spherique r th phi =
  r *! { x = cos th *. cos phi; y = sin th *. cos phi; z = sin phi }

(* L'aire d'un triangle *)
let aire_trig a b c = (norme @$ (b -! a) *^ (c -! a)) /. 2.

(* Directement sur les point_crb *)
let normeP m = norme m.p
let distanceP a b = distance a.p b.p
let aire_trigP a b c = aire_trig a.p b.p c.p


(* Je me sers beaucoup d'ensembles d'entiers *)
module ISet = Set.Make (struct
    type t = int
    let compare = Pervasives.compare
  end)
let set l = List.fold_left (fun s x -> ISet.add x s) ISet.empty l

let aff_set s = ISet.fold (Printf.sprintf "%d %s") s ""
