(* main.ml *)

open Init
open Maille
open Dessin
open Data

let () =
  (* Initialisation *)
  ignore (Glut.init Sys.argv);
  Glut.initDisplayMode ~depth:true ~double_buffer:true ();
  Glut.initWindowSize 800 600;
  ignore (Glut.createWindow "Surface Minimale");
  (***********)
  GlClear.clear [`color; `depth];
  Gl.enable `depth_test;
  GlFunc.depth_func `lequal;
  GlMisc.hint `perspective_correction `nicest;
  GlDraw.line_width 2.;

  (* Mes fonctions pour afficher et gérer l'IHM *)
  Glut.keyboardFunc clavier;
  Glut.reshapeFunc reshape;
  Glut.displayFunc affichage;
  Glut.mouseFunc souris;
  Glut.motionFunc mvt;
  Glut.timerFunc 20 dessin_auto ();

  (* Le menu *)
  begin let m = Glut.createMenu menu in
      Glut.setMenu m;
      Glut.attachMenu Glut.RIGHT_BUTTON;
      for x = 0 to Array.length surfaces - 1 do
        Glut.addMenuEntry surfaces.(x).nom x
      done;
  end;

  (* C'est parti ! *)
  menu ~value:0;
  Glut.mainLoop ()
