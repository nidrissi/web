(* operations.ml *)

open Init
open Data

(* L'isobarycentre d'une liste de points *)
let isobarycentre pts =
  let l = List.map (fun x -> points.tb.(x).p) pts in
  let n = foi (List.length l) in
  let bary = List.fold_left ( +! ) orig l in
    pt @$ (1. /. n) *! bary

(* Trouve le "milieu" de deux points, sur une courbe ou non *)
let milieu m n =
  let pm, pn = points.tb.(m), points.tb.(n) in
    match pm.crb, pn.crb with
      | None, _ | _, None -> isobarycentre [m;n]
      | Some i, Some j when i <> j -> isobarycentre [m;n]
      | Some num, _ ->
          let t = (pm.t +. pn.t) /. 2. in
          let p1 = surfaces.(!cur_surf).f.(num) t
          and p2 = surfaces.(!cur_surf).f.(num) (t +. pi) in
            if distanceP p1 pm +. distanceP p1 pn
              <= distanceP p2 pm +. distanceP p2 pn
            then p1 else p2

(* Remplace chaque point par l'isobarycentre de ses voisins *)
let isobarycentres () =
  let new_pts = Array.copy points.tb in
    for i = 0 to points.nb - 1 do
      if not (ISet.mem i points.vide) && points.tb.(i).crb = None then
        new_pts.(i) <- isobarycentre @$ voisins_de i
    done;
    Array.blit new_pts 0 points.tb 0 nb_max

(* Minimise localement la surface des triangles en bougeant de epsi
   chaque point dans les trois directions (3x3) *)
let minimise_local () =
  let change = ref 0 in
    for n = 0 to points.nb - 1 do
      if not (ISet.mem n points.vide) then begin
        (* Ça peut arriver quand on fusionne des points *)
        if ISet.cardinal voisins.(n) = 0 then supprime points n
        else if points.tb.(n).crb = None then begin
          let p = points.tb.(n) in
          let dp = ref orig in
          let aire_min = ref(aire_voisinage n) in
            (* 9 possibilités de nouvelle position de p *)
            for i = -1 to 1 do for j = -1 to 1 do for k = -1 to 1 do
              let dx, dy, dz = !epsi *. foi i, !epsi *. foi j, !epsi *. foi k
              in
              let dp' = { x = dx; y = dy; z = dz } in
                points.tb.(n) <- pt @$ p.p +! dp';
                let aire_min' = aire_voisinage n in
                  (* On choisit la meilleure *)
                  if aire_min' < !aire_min then begin
                    dp := dp';
                    aire_min := aire_min';
                  end;
                  points.tb.(n) <- p;
            done; done; done;
            if !dp <> orig then incr change;
            points.tb.(n) <- pt @$ p.p +! !dp;
        end
      end
    done;
    (* Si on n'a rien changé, le programme va diminuer epsi ensuite *)
    !change > 10

(* Coupe une arête trop longue en deux *)
let coupe_arete a b =
  (* Récupère les triangles contenant m et n *)
  match ISet.elements @$ ISet.inter voisins.(a) voisins.(b) with
    | [t] -> (* On est sur une frontière *)
        (* On crée quatre triangles en créant un point au milieu du
           segment [a;b] et un au milieu de l'arc [a;b] *)
        let x = troisieme t (a,b) in
        let mil = cree points @$ milieu a b in
        let iso = cree points @$ isobarycentre [a;b] in
          List.iter
            (fun l -> let n = cree triangles (set l) in
               List.iter (fun p -> voisins.(p) <- ISet.add n voisins.(p)) l)
            [ [a; x; iso]; [a;iso;mil]; [b; x; iso]; [b;iso;mil] ];
          ISet.iter (fun p -> voisins.(p) <- ISet.remove t voisins.(p))
            triangles.tb.(t);
          supprime triangles t
    | [t1; t2] -> (* Hors d'une frontière *)
        (* Même principe, mais on n'a qu'un point à créer cette fois
           si, au milieu du segment [a;b] *)
        let x1, x2 = troisieme t1 (a,b), troisieme t2 (a,b) in
        let mil = cree points @$ isobarycentre [a;b] in
          List.iter
            (fun l -> let n = cree triangles (set l) in
               List.iter (fun p -> voisins.(p) <- ISet.add n voisins.(p)) l)
            [ [a; x1; mil]; [x2; mil; a]; [b; x1; mil]; [mil; x2; b] ];
          ISet.iter
            (fun p -> voisins.(p) <- ISet.diff voisins.(p) (set [t1;t2]))
            (ISet.union triangles.tb.(t1) triangles.tb.(t2));
          List.iter (supprime triangles) [t1;t2]
    | l ->
        (* L'erreur finit par se corriger d'elle-même : ça ne se
           passe que quand des points sont trop proches, et il seront
           alors fusionnés *)
        Printf.printf
          "Ces triangles contiennent les points %d et %d :\n" a b;
        List.iter
          (fun t -> Printf.printf "%d : %s\n" t @$ aff_set triangles.tb.(t))
          l;
        flush_all ()

(* Coupe toutes les arêtes trop longues *)
let ajuste_aretes () =
  iter_trig begin
    fun i (a,b,c) -> match List.filter
      (fun (x,y) -> let px, py = points.tb.(x), points.tb.(y) in
         distanceP px py > !dist_max)
      [a,b;a,c;b,c]
    with
      | [] -> ()
      | (x,y) :: _ -> coupe_arete x y
  end

(* Fusionne deux points *)
let fusion m n =
  let suppr = ISet.inter voisins.(m) voisins.(n) in
  let mil = cree points @$ milieu m n in
    (* Dans l'ordre : on met en place les voisins du nouveau point
       fusionné, on remplace m et n par mil dans tous leurs voisins,
       on retire les triangles qui étaient voisins de m ET n *)
    voisins.(mil) <- ISet.diff (ISet.union voisins.(m) voisins.(n)) suppr;
    ISet.iter (fun t -> triangles.tb.(t) <- set @$
                 List.map (fun x -> if x=n||x=m then mil else x) @$
                 ISet.elements triangles.tb.(t))
      voisins.(mil);
    (* Attention aux suppositions fausses ! Il est possible qu'en
       remplaçant m et n par mil, deux triangles auparavant distincts
       deviennent le même triangle. De plus, ce triangle est
       à supprimer (son troisième point sera tout seul hors de la
       surface). Il faut faire attention et corriger
       éventuellement. *)
    ISet.iter
      (fun t1 -> ISet.iter
         (fun t2 ->
            if t1 <> t2 && ISet.equal triangles.tb.(t1) triangles.tb.(t2)
            then begin
              ISet.iter
                (fun p -> voisins.(p) <- ISet.diff voisins.(p) (set [t1;t2]))
                triangles.tb.(t2);
              List.iter (supprime triangles) [t1; t2];
            end)
         voisins.(mil))
      voisins.(mil);
    ISet.iter (fun t ->
                 ISet.iter
                   (fun p ->
                      voisins.(p) <- ISet.diff voisins.(p) suppr;
                      if ISet.cardinal voisins.(p) < 2 && p <> m && p <> n
                      then (supprime points p; voisins.(p) <- ISet.empty))
                   triangles.tb.(t);
                 supprime triangles t) suppr;
    List.iter (fun p -> supprime points p; voisins.(p) <- ISet.empty) [m;n]

(* Fusionne les points trop proches *)
let fusion_totale () =
  iter_trig begin
    fun i (a,b,c) -> match List.filter
      (fun (x,y) -> let px, py = points.tb.(x), points.tb.(y) in
         px.crb = None && py.crb = None && distanceP px py < !dist_max /. 4.)
      [a,b;a,c;b,c]
    with
      | [] -> ()
      | (x,y) :: _ -> fusion x y
  end
