(* maille.ml *)

open Init
open Data

(* Crée un triangle s'appuyant sur une surface 2π périodique*)
let init_tr surf =
  let pts = List.map (fun i -> surf (2. *. foi i *. pi /. 3.)) [0;1;2] in
    Array.of_list @$ List.map (cree points) pts

(* Un rectangle *)
let rectangle (a,b,c,d) =
  ignore @$ cree triangles @$ set [a;b;c];
  ignore @$ cree triangles @$ set [a;c;d]

(* Crée le support de la caténoïde *)
let cree_support_2 surface =
  let t = Array.map init_tr surface in
    List.iter rectangle @$
      List.map
      (fun (i,j) -> t.(0).(j), t.(1).(j), t.(1).(i), t.(0).(i))
      [ 0, 1; 1, 2; 2, 0]

(* Crée le support pour quatre cercles sur le tétraèdre *)
let cree_support_4 surface =
  Array.iter (ignore @@ init_tr) surface;
  (* Il faut trouver un moyen d'automatiser ça... *)
  List.iter rectangle [0,1,7,8; 1,2,10,11; 2,0,4,5;
                       3,4,8,6; 6,7,11,9; 9,10,5,3];
  List.iter (ignore @@ cree triangles) @$
    List.map set [ [0;4;8]; [1;7;11]; [2;10;5]; [3;6;9] ]

(* Crée le support pour Enneper *)
let cree_support_1 surface =
  let surf = surface.(0) in
    ignore @$ init_tr surf;
    ignore (cree triangles @$ set [0;1;2])

let cree_support surface =
  begin
    match Array.length surface with
      | 1 -> cree_support_1 surface
      | 2 -> cree_support_2 surface
      | 4 -> cree_support_4 surface
      | _ -> failwith "cree_support"
  end;
  iter_trig (fun i (a,b,c) -> List.iter
               (fun p -> voisins.(p) <- ISet.add i voisins.(p)) [a;b;c])
