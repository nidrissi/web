(* dessin.ml *)

open Init
open Data
open Maille
open Operations

let shape = ref `line_loop
let swap_shape () =
  shape :=
    if !shape = `triangles then `line_loop
    else `triangles

(* Le point de vue *)
let dist, phi, theta = ref 5.3, ref 0., ref 0.
let raz_PdV () =
  dist := 5.3; theta := 0.; phi := 0.
let angle_diff, dist_diff = 0.2, 0.5
let numer = ref false
(* L'ancienne position de la souris *)
let xold, yold = ref 0, ref 0
let bouge = ref false

(* Calcul automatique *)
let une_iter = ref false
let calc_auto = ref false
let stop_iso = ref false
let iterations = ref 0

(* Dessine tous les triangles *)
let dessin_triangles () =
  let triangle i (a,b,c) =
    GlDraw.begins !shape;
    let pa,pb,pc = points.tb.(a).p, points.tb.(b).p, points.tb.(c).p in
      List.iter (fun (c,p) -> GlDraw.color c; GlDraw.vertex3 p)
        [ (1.,0.,0.), (pa.x,pa.y,pa.z);
          (1.,1.,1.), (pb.x,pb.y,pb.z);
          (0.,0.,1.), (pc.x,pc.y,pc.z)
        ];
    GlDraw.ends ()
  in
    iter_trig triangle

(* Écrit du texte juste en dessous de la figure *)
let ecrit txt =
  (* Pour savoir où écrire : la plus petite cote des points *)
  let zmin =
    Array.fold_left (fun z p2 -> min z p2.p.z) 0.
      (Array.sub points.tb 0 points.nb) in
    GlDraw.color (1.,1.,1.);
    GlPix.raster_pos ~x:0. ~y:(-2.) ~z:(zmin -. 0.8) ();
    String.iter
      (fun c -> Glut.bitmapCharacter ~font:Glut.BITMAP_HELVETICA_18
         ~c:(int_of_char c)) txt

(* Écrit un nombre à côté de chaque point *)
let numerote () =
  for i = 0 to points.nb - 1 do
    if not (ISet.mem i points.vide) then begin
      let p = points.tb.(i).p in
        GlDraw.color (1.,1.,0.);
        GlPix.raster_pos ~x:p.x ~y:p.y ~z:p.z ();
        String.iter
          (fun c ->
             Glut.bitmapCharacter ~font:Glut.BITMAP_HELVETICA_10
               ~c:(int_of_char c)) (string_of_int i);
    end
  done

(* Efface l'écran, place la caméra et dessine *)
let affichage () =
  GlClear.clear [`color; `depth];
  GlMat.load_identity ();
  GluMat.look_at (!dist,0.,0.) (0.,0.,0.) (0.,0.,1.);
  (* Il faut placer cette instruction avant la rotation pour que le
     texte s'affiche correctement *)
  ecrit @$ donnees ();
  GlMat.rotate ~angle:!phi ~z:1. ();
  GlMat.rotate ~angle:!theta ~y:1. ();
  dessin_triangles ();
  if !numer then numerote ();
  Glut.swapBuffers ()

(* Fonction appelée quand la fenêtre est redimensionnée *)
let reshape ~w ~h =
  let ratio = (float_of_int w) /. (float_of_int h) in
    GlDraw.viewport 0 0 w h;
    GlMat.mode `projection;
    GlMat.load_identity ();
    GluMat.perspective 50.0 ratio (0.1, 100.0);
    GlMat.mode `modelview;
    GlMat.load_identity ()

(* Le menu *)
let menu ~value =
  raz ();
  raz_PdV ();
  stop_iso := false;
  calc_auto := false;
  cur_surf := value;
  cree_support @$ surfaces.(value).f;
  epsi := 1e-2;
  Glut.setWindowTitle
    ~title:(Printf.sprintf "Surface Minimale : %s" surfaces.(value).nom)

(* Fonction appelée quand l'utilisateur tape au clavier *)
let clavier ~key ~x ~y =
  begin match char_of_int key with
    | '\027' (* ESC *) -> exit 0
    | 's' -> swap_shape ()
    | ' ' -> calc_auto := not !calc_auto
    | 'u' -> une_iter := true
    | 'n' -> numer := not !numer
    | 'r' -> menu !cur_surf

    (* Contrôle manuel *)
    | '+' -> dist_max := !dist_max +. 0.01
    | '-' -> dist_max := !dist_max -. 0.01
    | 'i' -> isobarycentres ()
    | 't' -> ajuste_aretes ()
    | 'm' -> ignore @$ minimise_local ()
    | 'f' -> fusion_totale ()
    | _ -> ()
  end;
  Glut.postRedisplay ()

(* Quand l'utilisateur clique *)
let souris ~button ~state ~x ~y =
  begin
    match button, state with
      | Glut.LEFT_BUTTON, Glut.DOWN ->
          bouge := true;
          xold := x; yold := y
      | Glut.LEFT_BUTTON, Glut.UP ->
          bouge := false
      | Glut.MIDDLE_BUTTON, Glut.DOWN ->
          raz_PdV ()
      | Glut.OTHER_BUTTON 4, Glut.DOWN ->   (* Molette de la souris *)
          dist := !dist +. dist_diff
      | Glut.OTHER_BUTTON 3, Glut.DOWN ->
          dist := !dist -. dist_diff
      | _ -> ()
  end;
  Glut.postRedisplay ()

(* Quand l'utilisateur bouge la souris *)
let mvt ~x ~y =
  if !bouge then begin
    phi := !phi +. angle_diff *. float (x - !xold);
    theta := !theta +. angle_diff *. float (y - !yold);
    Glut.postRedisplay ()
  end;
  xold := x; yold := y

(* Dessine toutes les 20ms *)
let rec dessin_auto ~value =
  if !calc_auto || !une_iter then begin
    une_iter := false;
    incr iterations;
    if not !stop_iso then begin
      isobarycentres ();
      ignore @$ donnees ();
      if !depass = 0 then stop_iso := true;
    end
    else begin
      if not( minimise_local () ) then epsi := !epsi /. 2.;
      if !iterations mod 7 = 0 then fusion_totale ();
    end;
    if !iterations mod 10 = 0 then ajuste_aretes ();
    Glut.postRedisplay ()
  end;
  Glut.timerFunc 20 dessin_auto ()
