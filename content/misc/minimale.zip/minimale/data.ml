(* data.ml *)

open Init

let e_x = { x = 1.; y = 0.; z = 0. }
let e_y = { x = 0.; y = 1.; z = 0. }
let e_z = { x = 0.; y = 0.; z = 1. }

(* Un cercle de centre ctr, de rayon r, contenu dans le plan normal
   à n, u étant utilisé pour savoir où "commence" le cercle *)
let cercle_vec num ctr r n u = fun t ->
  let n = (1. /. norme n) *! n in
  let u = (1. /. norme u) *! u in
  { p = ctr +! r *! (cos t *! u +! sin t *! (n *^ u));
    t = t;
    crb = Some num }

(* Un cercle dans (xOy) type (cos t, sin t, 0) *)
let cercle num ctr r = cercle_vec num ctr r e_z e_x

(* Une ellipse de centre ctr, de rayon r, dans le plan normal à e_z *)
let ellipse n ctr r a b = fun t ->
  { p = ctr +! r *! { x = a *. cos t; y = b *. sin t; z = 0. };
    t = t;
    crb = Some n }

(* Les surfaces possibles *)
let catenoide = [| cercle 0 { x = 0.; y = 0.; z = 1. } 1.8;
                   cercle 1 { x = 0.; y = 0.; z = -1. } 1.8
                |]
let ellipses = [| ellipse 0 { x = 0.; y = 0.; z = 1. } 1. 0.8 1.2;
                  ellipse 1 { x = 0.; y = 0.; z = -1. } 1. 1.2 0.8
               |]

(* Les centres des quatres cercles forment un tétraèdre régulier *)
let super =
  let r_tetra = 1.3 in
  let r_crcl = 1.2 in
  let cercle n =
    (* L'angle entre deux segments joignant deux sommets d'un
       tétraèdre régulier et son centre *)
    let alpha = 2. *. atan(sqrt 2.) in
    let theta = float n *. 2. *. pi /. 3. in
    let ctr = spherique r_tetra theta (pi/.2.-.alpha) in
    let up = spherique r_tetra theta (-.alpha) in
      cercle_vec n ctr r_crcl ctr up
  in
    [| cercle_vec 0 (r_tetra *! e_z) r_crcl e_z (!- e_x);
       cercle 1; cercle 2; cercle 3 |]

(* La surface d'Enneper *)
let enneper =
  let r = 1. in
    [| fun t ->
         let u, v = r *. cos t, r *. sin t in
           { p = { x = u -. u**3. /. 3. +. u *. v**2.;
                   y = v -. v**3. /. 3. +. v *. u**2.;
                   z = u**2. -. v**2.
                 };
             crb = Some 0; t = t }
    |]

(* Les surfaces que j'ai définies. Attention, tout est interdépendant,
   elles sont supposées 2π périodiques par exemple, et pour "super" il ne
   vaut mieux pas modifier l'ordre dans lequel les surfaces sont
   définies... *)
type surface = { nom : string; f : (float -> Init.point) array }
let cur_surf = ref 0
let surfaces = [| { f = catenoide; nom = "Catenoide" };
                  { f = ellipses; nom = "Ellipses" };
                  { f = super; nom = "Super" };
                  { f = enneper; nom = "Enneper" }
               |]

(* La distance maximale entre deux points (l'utilisateur peut la
   modifier); le "pas" entre deux points dans minimise_local *)
let dist_max = ref 0.3
let epsi = ref 1e-2

(* Les différents tableaux (triangles et points) sont similaires : un
   "grand" tableau, un nombre de cases effectivement utilisées, et une
   liste de cases qui ne sont pas utilisées *)
type 'a tab = { tb : 'a array;
                defaut : 'a;
                mutable nb : int;
                mutable vide : ISet.t }
let nb_max = 10000
let cree_tab defaut = { tb = Array.make nb_max defaut;
                        vide = ISet.empty; nb = 0; defaut = defaut }

(* Crée un nouvel élément *)
let cree tab x =
  if ISet.is_empty tab.vide then begin
    tab.tb.(tab.nb) <- x;
    tab.nb <- tab.nb + 1;
    tab.nb - 1
  end else begin
    let n = ISet.choose tab.vide in
      tab.tb.(n) <- x;
      tab.vide <- ISet.remove n tab.vide;
      n
  end

(* Supprime un élément *)
let supprime tab i =
  if ISet.mem i tab.vide then failwith "Déjà supprimé";
  tab.vide <- ISet.add i tab.vide;
  tab.tb.(i) <- tab.defaut

(* Les tableaux de points et de triangles *)
let points = cree_tab @$ pt orig
let triangles = cree_tab ISet.empty
(* Donne le troisième point d'un triangle *)
let troisieme t (p1,p2) = ISet.choose @$
  ISet.diff triangles.tb.(t) (set [p1;p2])

(* Chaque point maintient de plus un ensemble de triangles dans lequel
   il est *)
let voisins = Array.make nb_max ISet.empty
let voisins_de p =
  ISet.elements @$
    ISet.remove p @$
    ISet.fold (fun j s -> ISet.union s triangles.tb.(j)) voisins.(p) ISet.empty

let iter_trig f =
  for i = 0 to triangles.nb - 1 do
    if not (ISet.mem i triangles.vide) then
      match ISet.elements triangles.tb.(i) with
        | [a;b;c] -> f i (a, b, c)
        | _ -> failwith (Printf.sprintf "Triangle %d contient %d points"
                           i (ISet.cardinal triangles.tb.(i)))
  done

(* Calcul d'aires *)
let aire_numero i j k = aire_trigP points.tb.(i) points.tb.(j) points.tb.(k)
let aire_trig_num t = match ISet.elements triangles.tb.(t) with
  | [a;b;c] -> aire_numero a b c
  | _ -> failwith (Printf.sprintf "Triangle %d contient %d points"
                     t (ISet.cardinal triangles.tb.(t)))
let aire_voisinage m =
  List.fold_left
    (fun tot tr -> tot +. aire_trig_num tr)
    0. @$ ISet.elements voisins.(m)


(* Remise à zéro *)
let raz () =
  Array.fill points.tb 0 nb_max points.defaut;
  points.vide <- ISet.empty;
  points.nb <- 0;
  Array.fill voisins 0 nb_max ISet.empty;

  Array.fill triangles.tb 0 nb_max triangles.defaut;
  triangles.vide <- ISet.empty;
  triangles.nb <- 0

(**************************)
(* Les données à afficher *)
(**************************)

(* Les données concernant l'état actuel de la surface *)
let aire = ref 0.
let d_max = ref 0.
let d_min = ref max_float
let depass = ref 0

(* Renvoit une chaîne décrivant l'état de la surface *)
let donnees () =
  aire := 0.; d_max := 0.; d_min := max_float; depass := 0;
  iter_trig
    (fun i (a,b,c) ->
       let pa,pb,pc = points.tb.(a), points.tb.(b), points.tb.(c) in
         aire := !aire +. aire_trigP pa pb pc;
         List.iter (fun d ->
                      if d > !dist_max then incr depass;
                      d_max := max d !d_max; d_min := min d !d_min)
           (List.map norme [pb.p -! pa.p; pc.p -! pa.p; pb.p -! pc.p]));
  Printf.sprintf ("Pts : %d ; Trig : %d ; Aire : %.2f ;" ^^
                    " Dist max %.3f, min %.3f (contrainte %.2f; depass : %d)")
    (points.nb - ISet.cardinal points.vide)
    (triangles.nb - ISet.cardinal triangles.vide)
    !aire !d_max !d_min !dist_max !depass
